!motor.origin[10] 5240
?motor.origin[10] 
!motor.initial[10] 293
?motor.initial[10]
!motor.reset.pos[10] 1440
?motor.reset.pos[10] 
